package com.example.android.ble;

/**
 * Created by jgomez on 3/05/16.
 */
public enum BLEMode {
    PERIPHERAL,
    CENTRAL,
    NONE, /* Classic BT mode */
}
